# 安全规范

## 敏感文件保护
以下目录或文件禁止修改：
- bin/*

## 输入验证
- 所有外部输入必须验证长度
- 禁止使用不安全的函数（strcpy, sprintf）
- 使用安全的替代函数（strncpy, snprintf）

# 代码规则约束

## 1 变量命名
- 全局变量：g_前缀，如 g_system_tick
- 静态全局变量：sg_前缀，如 sg_current_mode
- 局部变量：小写+下划线，如 temp_value
- 指针变量：p_前缀，如 p_buffer
- 常量：全大写+下划线，如 MAX_BUFFER_SIZE
- 模块内部全局：m_前缀，如 m_device_status

## 2 函数命名
- 公有函数：模块名_动作，如 uart_send_data()
- 私有函数：下划线开头+动作，如 _calculate_crc()
- 中断处理：模块名_irq，如 timer_irq_handler()
- 回调函数：模块名_on_事件，如 button_on_click()

## 3 宏和枚举值
- 宏定义：全大写，如 #define FLASH_SECTOR_SIZE 4096
- 枚举类型：以_E结尾，如 led_state_e
- 枚举值：全大写，如 LED_ON、LED_OFF
- 类型定义：以_t结尾，如 uart_config_t

## 4 代码格式规范
- 使用4个空格缩进，不使用TAB
- 括号采用K&R风格
- 每行不超过80个字符
- 长表达式需合理换行
- 运算符两边加空格
- 逗号后加空格

## 5 函数设计规范
- 函数体不超过30行，超过考虑拆分为子函数
- 函数参数不超过4个，超过使用结构体传递

## 6 注释规范
- 文件头必须包含版权和作者信息，作者默认为 mosser
- 所有导出函数必须有 Doxygen 风格注释
- 关键算法必须有思路注释
- 文件头注释
```c
/**
 * @file    uart_driver.c
 * @brief   UART驱动程序实现
 * @author  mosser
 * @date    2024-01-01
 * @version 1.0.0
 * 
 * @note    需要初始化时钟模块后才能使用
 * @warning 缓冲区大小需为2的幂次方
 */
 ```
- 函数注释
```c
/**
 * @brief   通过UART发送数据
 * @param   data    要发送的数据指针
 * @param   len     数据长度(字节)
 * @return  int32_t 成功返回发送字节数，失败返回错误码
 * @retval  >=0     成功发送的字节数
 * @retval  -1      参数错误
 * @retval  -2      硬件忙
 * 
 * @note    函数会阻塞直到发送完成或超时
 * @see     uart_receive()
 */
int32_t uart_send(const uint8_t *data, uint32_t len);
```
- 关键代码注释
```c
// 临界区保护：操作共享变量
ENTER_CRITICAL();
if (g_buffer_count > 0) {
    g_buffer_count--;
}
EXIT_CRITICAL();

/* 
 * 状态机处理：
 * STATE_IDLE   -> 等待数据
 * STATE_RECV   -> 接收数据中
 * STATE_DONE   -> 数据接收完成
 */
 ```
-特殊标记注释 
```c
// FIXME: 这里需要处理缓冲区溢出情况
// TODO: 添加DMA传输模式
// XXX: 此算法可能影响实时性，需要优化
// NOTE: 此寄存器在复位后值不确定
```

## 7 头文件规范
- 头文件结构
```c
#ifndef __UART_DRIVER_H__
#define __UART_DRIVER_H__

#ifdef __cplusplus
extern "C" {
#endif

/* 包含头文件 */
#include <stdint.h>
#include "system.h"

/* 宏定义 */
#define UART_BUFFER_SIZE    256
#define UART_TIMEOUT_MS     1000

/* 类型定义 */
typedef enum {
    UART_OK = 0,
    UART_ERROR,
    UART_BUSY
} uart_status_t;

/* 全局变量声明 */
extern uint32_t g_uart_irq_count;

/* 函数声明 */
void uart_init(void);
int32_t uart_send(const uint8_t *data, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* __UART_DRIVER_H__ */
```

- 头文件依赖最小化

## 8 变量使用规范
- 变量初始化
```c
// 所有变量必须初始化
static uint32_t g_counter = 0;
uint8_t buffer[32] = {0};
int32_t result = -1;
```
- 变量作用域最小化
```c
// 限制变量作用域
void process_data(void)
{
    // 只在函数内部使用的变量
    static uint32_t call_count = 0;  // 局部静态变量
    uint32_t temp_value = 0;         // 自动变量
    
    call_count++;
    // 处理逻辑
}
```
- 非0/1等常量需预定义
```c
// 使用const定义常量
const uint32_t SYSTEM_CLOCK = 72000000UL;
const float PI = 3.14159f;

// 使用enum定义相关常量
enum {
    QUEUE_SIZE = 10,
    MAX_RETRY = 3
};
```

## 9 错误处理规范
- 参数检查
```c
#include <assert.h>

void uart_send_byte(uint8_t *data)
{
    ASSERT(!data);  // 参数检查
    // 发送数据
}
// 生产代码可使用自定义断言
#define ASSERT(expr) \
    do { \
        if (!(expr)) { \
            error_handler(__FILE__, __LINE__); \
        } \
    } while(0)
```
- 返回值检查
```c
int32_t result = uart_send(data, len);
if (result < 0) {
    // 错误处理
    LOG_ERROR("UART send failed: %d", result);
    return ERROR_CODE;
}
```


## 10 内存管理规范
- 静态内存分配优先
```c
// 避免动态内存分配
#define TASK_STACK_SIZE 512
static uint32_t task_stack[TASK_STACK_SIZE];
```
- 缓冲区大小定义为2的幂
```c
// 方便取模运算
#define BUFFER_SIZE 256  // 2^8
static uint8_t g_buffer[BUFFER_SIZE];
```

## 11 模块化设计规范
- 模块接口清晰
```c
// uart.h - 公开接口
void uart_init(uart_config_t *config);
int32_t uart_write(uint8_t *data, uint32_t len);
int32_t uart_read(uint8_t *buffer, uint32_t len);

// uart.c - 私有实现
static void _uart_isr_handler(void);
static void _process_rx_data(void);
static uint8_t m_rx_buffer[RX_BUFFER_SIZE];
```
- 模块间解耦
```c
// 使用回调函数解耦
typedef void (*data_callback_t)(uint8_t *data, uint32_t len);
void uart_register_callback(data_callback_t callback);
```

## 12 代码审查清单
- 所有变量是否已初始化？
- 是否检查了所有返回值？
- 是否有潜在的缓冲区溢出？
- 是否考虑了边界条件？
- 是否存在死循环风险？
- 中断处理是否足够快？
- 是否有关键区保护？
- 代码是否符合规范格式？
- 注释是否足够且准确？
- 是否包含错误处理逻辑？
- 代码是否被截断？

# 单元测试
- 单元测试文件必须放在 tests/unit 目录下
- 所有编译产物（包括中间文件和最终文件）必须输出到 bin/ 目录
- 保持项目根目录整洁，避免编译文件污染

# 设计文档规范
- 某个模块代码所涉及的设计文档需包含以下章节
  - 概述
  - 模块结构设计
  - 可能用到的模块及功能
    ```text
    - include/gostc_log.h
      - 日志输出
    - include/re.h
      - 正则表达式预编译
      - 正则匹配
    ```
- 概述中需包含以下内容
  - 设计目标
  - 功能规则的细化设计
  - 设计限制注意事项
- 模块结构设计中需包含以下内容
  - 模块结构设计
  - 模块接口设计
- 模块接口设计注意事项
  - 需包含接口名称
  - 需包含接口功能
  - 需包含接口主要完成内容介绍
  - 需包含接口的简要流程分项
  - 需包含接口设计的注意事项
  - 不包含实际的设计代码
-